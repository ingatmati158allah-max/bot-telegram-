module.exports = {
  BOT_TOKEN: "BOT_TOKEN_LU",
  OWNER_IDS: ["CHAT_ID_LU"],
  OWNER_USERNAME: "p1atu",
};